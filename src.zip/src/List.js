// src/List.js
import React from 'react';

const items = ['Maçã', 'Banana', 'Cereja'];

export default function List() {
  return (
    <ul className="list-group">
      {items.map((item, i) => (
        <li key={i} className="list-group-item">
          {item}
        </li>
      ))}
    </ul>
  );
}
