// src/List3.js
import React, { useState } from 'react';

export default function List3() {
  const [items, setItems] = useState([]);
  const [text, setText] = useState('');

  const addItem = e => {
    e.preventDefault();
    if (!text.trim()) return;
    setItems(prev => [...prev, text.trim()]);
    setText('');
  };

  return (
    <div className="card p-3">
      <h5 className="card-title">Nova Tarefa</h5>
      <form onSubmit={addItem} className="input-group mb-3">
        <input
          className="form-control"
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder="Digite a tarefa"
        />
        <button className="btn btn-outline-primary" type="submit">
          Adicionar
        </button>
      </form>
      <ul className="list-group">
        {items.map((it, i) => (
          <li key={i} className="list-group-item">
            {it}
          </li>
        ))}
      </ul>
    </div>
  );
}
