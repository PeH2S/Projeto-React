import React from 'react';
import Gallery from '../components/Gallery';
import PackingList from '../components/PackingList';


const Ativ03 = () => {
  return (
    <div className="App">

      <Gallery />
      <PackingList />
    </div>
  );
};

export default Ativ03;
