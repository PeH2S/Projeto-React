// src/List4.js
import React, { useState } from 'react';

const initial = ['React', 'Vue', 'Angular', 'Svelte'];

export default function List4() {
  const [filter, setFilter] = useState('');

  return (
    <div className="mb-3">
      <input
        className="form-control mb-2"
        placeholder="Filtrar frameworks"
        value={filter}
        onChange={e => setFilter(e.target.value)}
      />
      <ul className="list-group">
        {initial
          .filter(item =>
            item.toLowerCase().includes(filter.toLowerCase())
          )
          .map((item, i) => (
            <li key={i} className="list-group-item">
              {item}
            </li>
          ))}
      </ul>
    </div>
  );
}
