// src/Form2.js
import React, { useState } from 'react';

export default function Form2() {
  const [formData, setFormData] = useState({ name: '', email: '' });

  const handleChange = e => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = e => {
    e.preventDefault();
    alert(`Nome: ${formData.name}\nEmail: ${formData.email}`);
  };

  return (
    <div className="card p-4">
      <h5 className="card-title">Formulário 2</h5>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="name2" className="form-label">Nome</label>
          <input
            id="name2"
            name="name"
            className="form-control"
            value={formData.name}
            onChange={handleChange}
            placeholder="Seu nome"
          />
        </div>
        <div className="mb-3">
          <label htmlFor="email2" className="form-label">Email</label>
          <input
            id="email2"
            name="email"
            type="email"
            className="form-control"
            value={formData.email}
            onChange={handleChange}
            placeholder="seu@exemplo.com"
          />
        </div>
        <button type="submit" className="btn btn-success">
          Enviar
        </button>
      </form>
    </div>
  );
}
