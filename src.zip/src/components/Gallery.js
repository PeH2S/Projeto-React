import React from 'react';
import Profile from './Profile.js';

export default function Gallery() {
  return (
    <section>
      <h2>Galeria</h2>
      <Profile />
      <Profile />
      <Profile />
    </section>
  );
}
