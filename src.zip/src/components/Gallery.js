import React from 'react';
import { Profile } from './Profile';  


export default function Gallery() {
  return (
    <section>
      <h2>Galeria</h2>
      <Profile />
      <Profile />
      <Profile />
    </section>
  );
}
