import React from 'react';
import ContadorPessoas from './ContadorPessoas'; // importação do componente

export default function Ativ02() {
    return (
        <div>
            <h2>Atividade 01 - Contador de Pessoas</h2>
            <ContadorPessoas />
        </div>
    );
}
