// src/Form.js
import React, { useState } from 'react';

export default function Form() {
  const [text, setText] = useState('');

  const handleSubmit = e => {
    e.preventDefault();
    alert(`Você digitou: ${text}`);
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 border rounded bg-light">
      <div className="mb-3">
        <label htmlFor="inputText" className="form-label">
          Digite algo
        </label>
        <input
          id="inputText"
          type="text"
          className="form-control"
          value={text}
          onChange={e => setText(e.target.value)}
          placeholder="Seu texto aqui..."
        />
      </div>
      <button type="submit" className="btn btn-primary">
        Enviar
      </button>
    </form>
  );
}
