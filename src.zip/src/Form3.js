// src/Form3.js
import React, { useState } from 'react';

export default function Form3() {
  const [person, setPerson] = useState({ first: '', last: '', age: '' });

  const handleChange = e => {
    const { name, value } = e.target;
    setPerson(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = e => {
    e.preventDefault();
    alert(`Pessoa: ${person.first} ${person.last}, ${person.age} anos`);
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 border rounded">
      <h5 className="mb-3">Formulário 3</h5>
      <div className="row g-3 mb-3">
        <div className="col-md-4">
          <input
            name="first"
            className="form-control"
            value={person.first}
            onChange={handleChange}
            placeholder="Primeiro nome"
          />
        </div>
        <div className="col-md-4">
          <input
            name="last"
            className="form-control"
            value={person.last}
            onChange={handleChange}
            placeholder="Sobrenome"
          />
        </div>
        <div className="col-md-4">
          <input
            name="age"
            type="number"
            className="form-control"
            value={person.age}
            onChange={handleChange}
            placeholder="Idade"
          />
        </div>
      </div>
      <button type="submit" className="btn btn-warning">
        Enviar
      </button>
    </form>
  );
}
